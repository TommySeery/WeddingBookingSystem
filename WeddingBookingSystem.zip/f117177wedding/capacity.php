<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    if(isset($_REQUEST['submit'])){
        $responseData = $_REQUEST;
        $min = $responseData["minCapacity"];
        $max = $responseData["maxCapacity"];

        if($min>0 && $max>0 && $min<=$max && is_int((int)$min) && is_int((int)$max)){

        include "coa123-mysql-connect.php";

        $conn = mysqli_connect($servername,$username,$password,$dbName);

        if(!$conn){
            die("Connection failed: ".mysqli_connect_error());
        }

        $sql = "SELECT name, weekend_price, weekday_price 
        FROM venue 
        WHERE licensed = 1 
        AND capacity BETWEEN {$min} AND {$max}";

        $result = mysqli_query($conn,$sql);

        $table = "<table border=1><tr>
            <th>Name</th>
            <th>Weekend Price</th>
            <th>Weekend Price</th>
            </tr>";

        if(mysqli_num_rows($result)>0){
            while($row = mysqli_fetch_array($result)){
                $table.= "<tr><td>".$row[0] . "</td><td>" . $row[1] . "</td><td>" . $row[2] . "</td></tr>";
            }
        }
        $table.= "</table>";
        echo $table;
    }
    else{
        echo "Invalid Input";
    }
}
    ?>
</table>
</body>
</html>