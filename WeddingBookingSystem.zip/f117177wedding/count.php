<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        if(isset($_REQUEST['submit'])){
            $responseData = $_REQUEST;
            $month = $responseData["month"];

            if($month <=12 && $month >=1){
                echo "<table border='1'>
                <tr>
                    <th>venue_id</th>
                    <th>Number of Bookings</th>
                </tr>";

                include "coa123-mysql-connect.php";

                $conn = mysqli_connect($servername,$username,$password,$dbName);
            
                if(!$conn){
                    die("Connection failed: ".mysqli_connect_error());
                }
            
                $sql = "SELECT name, COUNT(venue_booking.venue_id) 
                FROM venue_booking 
                INNER JOIN venue 
                WHERE venue.venue_id = venue_booking.venue_id 
                AND MONTH(booking_date) = {$month} 
                GROUP BY venue_booking.venue_id 
                ORDER BY COUNT(venue_booking.venue_id) DESC";
            
                $result = mysqli_query($conn,$sql);
            
                if(mysqli_num_rows($result)>0){
                    while($row = mysqli_fetch_array($result)){
                        echo "<tr><td>".$row[0] .  "</td><td>" . $row[1] . "</td></tr>";
                    }
                }

                echo "</table>";
            }else{
                echo "Invalid input";
            }
    }
    ?>
</body>
</html>