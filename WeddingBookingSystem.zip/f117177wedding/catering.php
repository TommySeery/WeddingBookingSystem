<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="catering.html">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table border="1">
        <?php
        if(isset($_REQUEST['submit'])){
            $table = "<tr><th>cost per person &#8594<br>party size &#8595</th>";
            $responseData = $_REQUEST;
            $min = $responseData["min"];
            $max = $responseData["max"];

            
            for($i=1;$i<=5;$i++){
                $table.="<th>".$responseData["c".$i]."</th>";
            }
            $table.="</tr>";
            $j; 
            for($i=$min;$i<=$max;$i+=5){
                $table.="<tr><td>".$min."</td>";
                for($j=1;$j<=5;$j++){
                    $table.="<td>".($i*$responseData["c".$j])."</td>";
                }
                $table.="</tr>";
            }
        
        echo $table;
}

        ?>
    </table>
</body>
</html>
