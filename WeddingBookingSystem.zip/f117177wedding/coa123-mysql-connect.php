<?php
$servername = "sci-mysql";
$dbName = "coa123wdb";
$username = "coa123wuser";
$password = "grt64dkh!@2FD";
?>